from __future__ import annotations

import asyncio
from typing import Any

from faststream.rabbit.fastapi import RabbitMessage
from faststream.redis.fastapi import Redis, RedisMessage

from app.config.settings import settings
from app.infra.clients.stream import stream_client
from app.schemas.base import EmailSchema
from app.schemas.route_schemas.orders import OrderSchemaIn, OrderSchemaOut
from app.utils.errors import ServiceError
from app.utils.logging_service import stream_logger


async def _run_background(coro: Any, task_name: str) -> None:
    task = asyncio.create_task(coro, name=task_name)

    def _log_task_result(done_task: asyncio.Task[Any]) -> None:
        try:
            done_task.result()
        except Exception as exc:
            stream_logger.error(
                "Background task %s failed: %s",
                task_name,
                str(exc),
                exc_info=True,
            )

    task.add_done_callback(_log_task_result)


@stream_client.redis_router.subscriber(
    stream=settings.redis.get_stream_name("email")
)
async def handle_send_email(
    body: EmailSchema,
    msg: RedisMessage,
    redis: Redis,
) -> None:
    from app.background_tasks.workflows import send_notification_workflow

    await _run_background(
        send_notification_workflow(body.model_dump()),
        task_name="send_notification_workflow",
    )


@stream_client.redis_router.subscriber(
    stream=settings.redis.get_stream_name("order-pipeline")
)
async def handle_order_pipeline(
    body: OrderSchemaOut,
    msg: RedisMessage,
    redis: Redis,
) -> None:
    from app.background_tasks.workflows import order_processing_workflow

    await _run_background(
        order_processing_workflow(body.model_dump()),
        task_name="order_processing_workflow",
    )


@stream_client.redis_router.subscriber(
    stream=settings.redis.get_stream_name("order-send")
)
async def handle_order_send_to_skb(
    body: OrderSchemaOut,
    msg: RedisMessage,
    redis: Redis,
) -> None:
    from app.background_tasks.workflows import create_skb_order_workflow

    await _run_background(
        create_skb_order_workflow(body.model_dump()),
        task_name="create_skb_order_workflow",
    )


@stream_client.redis_router.subscriber(
    stream=settings.redis.get_stream_name("order-get-result")
)
async def handle_order_get_result(
    body: OrderSchemaOut,
    msg: RedisMessage,
    redis: Redis,
) -> None:
    from app.background_tasks.workflows import get_skb_order_result_workflow

    await _run_background(
        get_skb_order_result_workflow(body.model_dump()),
        task_name="get_skb_order_result_workflow",
    )


@stream_client.rabbit_router.subscriber(
    settings.queue.get_queue_name("order-create")
)
async def handle_order_init_create(
    body: dict[str, Any] | list[dict[str, Any]],
    msg: RabbitMessage,
) -> None:
    from app.services.route_services.orders import get_order_service
    from app.utils.utils import utilities

    try:
        raw_data = await utilities.decode_bytes(body)
        data_list = raw_data if isinstance(raw_data, list) else [raw_data]

        model_list = [
            OrderSchemaIn.model_validate(item).model_dump()
            for item in data_list
        ]

        service = get_order_service()
        if isinstance(raw_data, list):
            await _run_background(
                service.add_many(model_list),
                task_name="order_service.add_many",
            )
        else:
            await _run_background(
                service.add(model_list[0]),
                task_name="order_service.add",
            )

    except Exception as exc:
        raise ServiceError(f"Ошибка при создании заказа: {str(exc)}") from exc
