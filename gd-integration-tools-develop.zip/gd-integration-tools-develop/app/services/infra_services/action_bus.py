from datetime import timedelta
from typing import Any, Awaitable, Callable

from fastapi import Request

from app.api.dsl.invocation import EventPublishSpec
from app.infra.clients.stream import stream_client
from app.schemas.invocation import (
    ActionCommandMetaSchema,
    ActionCommandSchema,
    InvocationOptionsSchema,
)
from app.utils.enums.invocation import BrokerKind, InvokeMode
from app.utils.errors import ServiceError


__all__ = (
    "ActionBusService",
    "get_action_bus_service",
)


class ActionBusService:
    """
    Универсальный сервис исполнения action-вызовов.

    Поддерживает сценарии:
    - direct execution;
    - event publish;
    - delayed publish;
    - cron publish;
    - re-dispatch из message handlers.
    """

    async def invoke(
        self,
        *,
        request: Request,
        invoke: InvocationOptionsSchema,
        publish_spec: EventPublishSpec,
        direct_call: Callable[[], Awaitable[Any]],
        source_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Выполняет action из HTTP.
        """
        try:
            is_scheduled = (
                invoke.delay_seconds is not None or invoke.cron is not None
            )

            if invoke.mode == InvokeMode.direct and not is_scheduled:
                result = await direct_call()
                return {
                    "status": "completed",
                    "transport": "direct",
                    "result": result,
                }

            command = self._build_command_from_http(
                request=request,
                publish_spec=publish_spec,
                source_kwargs=source_kwargs,
                invoke=invoke,
            )

            publish_result = await self._publish_command(
                command=command,
                publish_spec=publish_spec,
                invoke=invoke,
            )

            if is_scheduled:
                return {
                    "status": "scheduled",
                    "transport": publish_spec.broker.value,
                    "job_id": publish_result,
                    "command": command.model_dump(),
                }

            return {
                "status": "queued",
                "transport": publish_spec.broker.value,
                "command": command.model_dump(),
            }
        except Exception as exc:
            raise ServiceError from exc

    async def invoke_from_command(
        self,
        *,
        command: ActionCommandSchema,
        invoke: InvocationOptionsSchema,
        publish_spec: EventPublishSpec,
        direct_call: Callable[[], Awaitable[Any]],
        source_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Выполняет action из message handler.

        Если mode=direct и нет schedule — вызывает service сразу.
        Иначе republish в broker/scheduler.
        """
        try:
            is_scheduled = (
                invoke.delay_seconds is not None or invoke.cron is not None
            )

            if invoke.mode == InvokeMode.direct and not is_scheduled:
                result = await direct_call()
                return {
                    "status": "completed",
                    "transport": "direct",
                    "result": result,
                }

            next_command = self._build_command_from_message(
                command=command,
                publish_spec=publish_spec,
                source_kwargs=source_kwargs,
                invoke=invoke,
            )

            publish_result = await self._publish_command(
                command=next_command,
                publish_spec=publish_spec,
                invoke=invoke,
            )

            if is_scheduled:
                return {
                    "status": "scheduled",
                    "transport": publish_spec.broker.value,
                    "job_id": publish_result,
                    "command": next_command.model_dump(),
                }

            return {
                "status": "queued",
                "transport": publish_spec.broker.value,
                "command": next_command.model_dump(),
            }
        except Exception as exc:
            raise ServiceError from exc

    def _build_command_from_http(
        self,
        *,
        request: Request,
        publish_spec: EventPublishSpec,
        source_kwargs: dict[str, Any],
        invoke: InvocationOptionsSchema,
    ) -> ActionCommandSchema:
        payload = publish_spec.payload_factory(source_kwargs, request)
        payload["invoke"] = invoke.model_dump(exclude_none=True)

        if publish_spec.meta_factory is not None:
            meta = publish_spec.meta_factory(source_kwargs, request)
        else:
            meta = ActionCommandMetaSchema(
                source="http",
                request_path=request.url.path,
            )

        return ActionCommandSchema(
            action=publish_spec.action,
            payload=payload,
            meta=meta,
        )

    def _build_command_from_message(
        self,
        *,
        command: ActionCommandSchema,
        publish_spec: EventPublishSpec,
        source_kwargs: dict[str, Any],
        invoke: InvocationOptionsSchema,
    ) -> ActionCommandSchema:
        payload = publish_spec.payload_factory(source_kwargs, None)
        payload["invoke"] = invoke.model_dump(exclude_none=True)

        return ActionCommandSchema(
            action=publish_spec.action,
            payload=payload,
            meta=ActionCommandMetaSchema(
                source=command.meta.source,
                request_path=command.meta.request_path,
            ),
        )

    async def _publish_command(
        self,
        *,
        command: ActionCommandSchema,
        publish_spec: EventPublishSpec,
        invoke: InvocationOptionsSchema,
    ) -> str | None:
        delay = (
            timedelta(seconds=invoke.delay_seconds)
            if invoke.delay_seconds is not None
            else None
        )

        if publish_spec.broker == BrokerKind.redis:
            return await stream_client.publish_to_redis(
                stream=publish_spec.destination,
                message=command.model_dump(),
                delay=delay,
                cron=invoke.cron,
            )

        if publish_spec.broker == BrokerKind.rabbit:
            return await stream_client.publish_to_rabbit(
                queue=publish_spec.destination,
                message=command.model_dump(),
                delay=delay,
                cron=invoke.cron,
            )

        raise ValueError(f"Unsupported broker: {publish_spec.broker}")


def get_action_bus_service() -> ActionBusService:
    """
    Возвращает экземпляр ActionBusService.
    """
    return ActionBusService()
