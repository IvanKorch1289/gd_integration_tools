from faststream.rabbit.fastapi import RabbitMessage
from faststream.redis.fastapi import Redis, RedisMessage

from app.config.settings import settings
from app.infra.clients.stream import stream_client
from app.schemas.invocation import ActionCommandSchema
from app.services.infra_services.action_registry import action_handler_registry
from app.utils.logging_service import stream_logger


__all__ = (
    "handle_redis_action_command",
    "handle_rabbit_action_command",
)


@stream_client.redis_router.subscriber(
    stream=settings.redis.get_stream_name("actions")
)
async def handle_redis_action_command(
    body: ActionCommandSchema,
    msg: RedisMessage,
    redis: Redis,
) -> None:
    """
    Универсальный Redis handler для action-команд.
    """
    stream_logger.info(
        "Redis action received action=%s correlation_id=%s",
        body.action,
        getattr(msg, "correlation_id", None),
    )
    await action_handler_registry.dispatch(body)


@stream_client.rabbit_router.subscriber(
    settings.queue.get_queue_name("actions")
)
async def handle_rabbit_action_command(
    body: ActionCommandSchema,
    msg: RabbitMessage,
) -> None:
    """
    Универсальный RabbitMQ handler для action-команд.
    """
    stream_logger.info(
        "Rabbit action received action=%s correlation_id=%s",
        body.action,
        getattr(msg, "correlation_id", None),
    )
    await action_handler_registry.dispatch(body)
