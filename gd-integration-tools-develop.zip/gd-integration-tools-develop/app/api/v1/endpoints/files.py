from fastapi import APIRouter, File, Header, Request, UploadFile, status
from fastapi_utils.cbv import cbv

from app.api.routers_factory import create_router_class
from app.schemas.filter_schemas.files import FileFilter
from app.schemas.route_schemas.files import FileSchemaIn
from app.services.infra_services.antivirus import (
    get_antivirus_service_dependency,
)
from app.services.infra_services.s3 import get_s3_service_dependency
from app.services.route_services.files import get_file_service
from app.utils.decorators.limiting import route_limiting


__all__ = (
    "router",
    "storage_router",
)


storage_router = APIRouter()


@cbv(storage_router)
class StorageCBV:
    service = get_s3_service_dependency()
    antivirus_service = get_antivirus_service_dependency()

    @storage_router.post(
        "/upload_file",
        status_code=status.HTTP_201_CREATED,
        summary="Проверить прикреплённый файл и сохранить в S3",
        operation_id="uploadFileStorageUploadFilePostUnique",
    )
    @route_limiting
    async def upload_file_in_s3(
        self,
        request: Request,
        file: UploadFile = File(...),
        multipart_field_name: str | None = None,
        x_api_key: str = Header(...),
    ):
        content = await file.read()

        result = await self.antivirus_service.scan_and_upload_file(
            file_bytes=content,
            filename=file.filename or "uploaded_file",
            content_type=file.content_type,
            multipart_field_name=multipart_field_name,
        )

        return {
            "uploaded": result["uploaded"],
            "filename": result["filename"],
            "key": result["key"],
            "size": len(content),
            "headers": {
                "content-disposition": file.headers.get("content-disposition"),
                "content-type": file.content_type,
            },
            "scan_result": result["scan_result"],
        }

    @storage_router.get(
        "/download_file/{file_uuid}",
        status_code=status.HTTP_200_OK,
        summary="Скачать файл из S3",
        operation_id="getDownloadFileByUuidUnique",
    )
    @route_limiting
    async def download_file(
        self,
        request: Request,
        file_uuid: str,
        x_api_key: str = Header(...),
    ):
        return await self.service.download_file(key=file_uuid)

    @storage_router.post(
        "/delete_file/",
        status_code=status.HTTP_204_NO_CONTENT,
        summary="Удалить файл из S3",
        operation_id="deleteFileByUuidUnique",
    )
    @route_limiting
    async def delete_file(
        self,
        request: Request,
        file_uuid: str,
        x_api_key: str = Header(...),
    ):
        await self.service.delete_file_object(key=file_uuid)

    @storage_router.get(
        "/get_download_link_file/{file_uuid}",
        status_code=status.HTTP_200_OK,
        summary="Получить ссылку на скачивание файла из S3",
        operation_id="getDownloadLinkFileUnique",
    )
    @route_limiting
    async def get_download_link_file(
        self,
        request: Request,
        file_uuid: str,
        x_api_key: str = Header(...),
    ):
        return await self.service.generate_download_url(key=file_uuid)

    @storage_router.get(
        "/get_file_base64/{file_uuid}",
        status_code=status.HTTP_200_OK,
        summary="Получить файл в формате base64",
        operation_id="getFileBase64Unique",
    )
    @route_limiting
    async def get_file_base64(
        self,
        request: Request,
        file_uuid: str,
        x_api_key: str = Header(...),
    ):
        return await self.service.get_file_base64(key=file_uuid)

    @storage_router.post(
        "/scan_file/{file_uuid}",
        status_code=status.HTTP_200_OK,
        summary="Проверить файл из S3 антивирусом",
        operation_id="scanFileByUuidUnique",
    )
    @route_limiting
    async def scan_file_in_antivirus(
        self,
        request: Request,
        file_uuid: str,
        multipart_field_name: str | None = None,
        x_api_key: str = Header(...),
    ):
        return await self.antivirus_service.scan_s3_file(
            key=file_uuid,
            multipart_field_name=multipart_field_name,
        )


router = APIRouter()

FileCBV = create_router_class(
    router=router,
    schema_in=FileSchemaIn,
    service=get_file_service(),
    filter_class=FileFilter,
)
