# План доработки gd_integration_tools — Production Readiness

> На основе анализа v9 + собственный аудит кодовой базы.
> Дата плана: 2026-06-02.

---

## 1. Факты из аудита (проверено инструментально)

| Параметр | Значение | Статус |
|----------|----------|--------|
| Python (pyproject.toml) | `>=3.14,<3.15` | 🔴 Риск — pydantic-core не совместим с 3.14 |
| pydantic | `>=2.10.3` | ⚠️ Зависит от pydantic-core (PyO3 0.24 max=3.13) |
| asyncpg | `>=0.31.0` | ⚠️ C-extension, wheels для cp314 не гарантированы |
| polars | `>=1.20.0` | ⚠️ Rust-based, требует пересборки |
| nemo-guardrails | **Отсутствует в deps** | ✅ Не блокирует сборку (есть только `nemo_client.py`) |
| Тестовое покрытие (baseline) | 50.0% | 🔴 Ниже цели 75% |
| Реальное покрытие (оценка) | ~59% | 🔴 Ниже цели 75% |
| Покрытие infrastructure | ~26.5% | 🔴 Критически низкое |
| Тестовых файлов | 679 | — |
| Ошибок коллекции pytest | 5 | 🟡 Блокируют точный замер |
| Processor-классов | 322 | — |
| Из 13 Groovy DSL методов — есть | 1 (SortProcessor) | 🔴 12 отсутствуют |
| ConvertersMixin методов | 5 из ~34 | 🟡 Недостаточно |
| ConsulConfigStore | Отсутствует | ❌ Не реализован |
| God-файлов (>300 строк) | 166 | 🔴 Требуют рефакторинга |
| Топ god-файл | features.py (2825 строк) | 🔴 |

---

## 2. Критические блокеры для production

1. **Python 3.14 совместимость** — `pydantic-core` (PyO3 0.24) не собирается под 3.14. Без него не работает весь стек Pydantic → FastAPI → DSL.
2. **Тестовое покрытие 59%** — ниже целевого 75%. Слой `infrastructure` — 26.5%.
3. **Отсутствие core Groovy DSL процессоров** — `.collect`, `.find_all`, `.group_by`, `.or_else` (P1) отсутствуют. Это gaps для миграции Camel/Groovy-скриптов.
4. **God-объекты** — 166 файлов >300 строк, 5 файлов >1000 строк. Технический долг растет.

---

## 3. Варианты реализации

### Вариант А — Консервативный (рекомендуемый)

**Python**: снизить до `>=3.13,<3.15`. Это снимает блокирующий риск pydantic-core, asyncpg, polars.

**Приоритеты**:
- **Неделя 1**: Python 3.13 downgrade + фикс 5 ошибок коллекции тестов + аудит покрытия
- **Недели 2-4**: Целевое наращивание тестов (infrastructure → 50%, core → 70%, dsl → 65%)
- **Недели 3-4**: Groovy DSL P1 процессоры (Collect, FindAll, GroupBy, OrElse) + их DSL-методы
- **Неделя 4**: ConsulConfigStore (core/config/) + docker-compose.infra.yml дополнение
- **Параллельно**: God-файлы — по одному за спринт (features.py → разбить на модуль)

**Преимущества**: стабильность, быстрый проход CI, нет blockers.
**Недостатки**: не cutting-edge, откладывает 3.14.

### Вариант Б — Агрессивный (оставить 3.14)

**Python**: оставить `>=3.14,<3.15`, но:
- Пин pydantic-core из main/snapshot (PyO3 0.25+ когда выйдет)
- Все C-extensions (asyncpg, polars, cryptography) — build from source в CI
- Исключить nemo-guardrails из MVP

**Приоритеты**: те же, но + настройка CI pipeline для сборки из source.

**Преимущества**: соответствие заявленной архитектуре.
**Недостатки**: CI будет красным неделями, непредсказуемые баги runtime, блокирует release.

---

## 4. Этапы плана (Вариант А — детализация)

### Этап 0. Python 3.13 downgrade (1-2 дня)
- `pyproject.toml`: `requires-python = ">=3.13,<3.15"`
- Убрать/закомментировать зависимости, которые точно не работают под 3.13 (если есть)
- Обновить lock-файлы
- CI: проверить сборку

### Этап 1. Тестовая инфраструктура (3-5 дней)
- Исправить 5 ошибок коллекции pytest
- Добавить `pytest-xdist` для ускорения прогона
- Полный прогон coverage с точными цифрами по слоям
- Baseline: coverage.json → актуальные цифры

### Этап 2. Наращивание покрытия (2-3 недели)
- **infrastructure/**: target с 26% до 50% — unit-тесты для cache, db, messaging backends
- **services/**: target с 51% до 65% — mock-based тесты для внешних вызовов
- **dsl/**: target с 53% до 65% — тесты для новых процессоров (сразу с покрытием)
- **entrypoints/**: target с ~40% до 60% — тесты на routing, auth, serialization

### Этап 3. Groovy DSL P1 процессоры (1 неделя)
- `CollectProcessor` + `.collect(field="name")`
- `FindAllProcessor` + `.find_all(condition="age > 18")`
- `GroupByProcessor` + `.group_by(field="category")`
- `OrElseProcessor` + `.or_else(default="N/A")`
- Каждый процессор: модель Pydantic, `@processor` декоратор, unit-тесты, JSON-schema

### Этап 4. ConsulConfigStore (2-3 дня)
- `src/backend/core/config/consul_config.py`: `ConsulConfigStore`
- Watch API (blocking queries)
- Интеграция в lifespan startup
- Unit-тесты с mock consul client

### Этап 5. God-файлы — первый заход (1 неделя)
- `features.py` (2825 строк) → декомпозиция на подмодули
- `integration.py` (2183 строк) → выделение helper-модулей
- Цель: ни одного файла >500 строк в целевых модулях

### Этап 6. Консолидация concerns (3-5 дней)
- Кэш 6 реализаций → 2 (Redis + in-memory)
- Логи 4 реализации → 1 (structlog)
- Circuit Breaker 3 → 1 (ResilienceCoordinator)
- Rate Limiter 3 → 1

---

## 5. Критерии завершения (Definition of Done)

- [ ] Python `requires-python = ">=3.13,<3.15"` — CI green
- [ ] Покрытие строк ≥65% (шаг к 75%)
- [ ] Покрытие ветвей ≥55%
- [ ] 0 ошибок коллекции pytest
- [ ] 4 P1 Groovy DSL процессора реализованы + протестированы
- [ ] ConsulConfigStore реализован + протестирован
- [ ] God-файлов >1000 строк: 0 (was 5)
- [ ] `make lint && make type-check && make test` — green

---

## 6. Что НЕ входит в этот план (out of scope)

- P2/P3 Groovy DSL процессоры (Find, Sort, Each, Flatten, Unique, Plus и др.)
- ConvertersMixin 35 методов
- AI Guardrails (NeMo / Guardrails AI)
- CDC завершение (Debezium)
- Performance tuning (connection pools, batching)
- Документация пользователей (docs/users/)

> Эти направления — следующие этапы после достижения 65%+ покрытия и стабилизации CI.
