from typing import Any

from fastapi import status
from pydantic import BaseModel

from app.config.settings import settings
from app.repositories.files import FileRepository, get_file_repo
from app.repositories.orders import OrderRepository, get_order_repo
from app.schemas.base import BaseSchema
from app.schemas.route_schemas.orders import (
    OrderSchemaIn,
    OrderSchemaOut,
    OrderVersionSchemaOut,
)
from app.services.infra_services.events import stream_client
from app.services.infra_services.s3 import S3Service, get_s3_service_dependency
from app.services.route_services.base import BaseService
from app.services.route_services.skb import APISKBService, get_skb_service
from app.utils.decorators.caching import response_cache
from app.utils.decorators.singleton import singleton
from app.utils.enums.skb import ResponseTypeChoices
from app.utils.errors import NotFoundError, ServiceError
from app.utils.utils import utilities


__all__ = (
    "OrderService",
    "get_order_service",
)


@singleton
class OrderService(
    BaseService[
        OrderRepository,
        OrderSchemaOut,
        OrderSchemaIn,
        OrderVersionSchemaOut,
    ]
):
    """
    Сервис для работы с заказами.

    Отвечает за:
    - CRUD-операции поверх заказов;
    - отправку запросов в СКБ-Техно;
    - получение JSON/PDF-результатов;
    - работу с файловым хранилищем;
    - публикацию событий в Redis и RabbitMQ.
    """

    def __init__(
        self,
        schema_in: type[BaseModel],
        schema_out: type[BaseModel],
        version_schema: type[BaseModel],
        repo: OrderRepository,
        file_repo: FileRepository,
        request_service: APISKBService,
        s3_service: S3Service,
    ) -> None:
        """
        Инициализирует сервис заказов.

        Args:
            schema_in: Входная схема заказа.
            schema_out: Выходная схема заказа.
            version_schema: Схема версии заказа.
            repo: Репозиторий заказов.
            file_repo: Репозиторий файлов.
            request_service: Сервис интеграции с API СКБ-Техно.
            s3_service: Сервис работы с S3.
        """
        super().__init__(
            repo=repo,
            request_schema=schema_in,
            response_schema=schema_out,
            version_schema=version_schema,
        )
        self.file_repo = file_repo
        self.request_service = request_service
        self.s3_service = s3_service

    async def _get_order_data(self, order_id: int) -> dict[str, Any]:
        """
        Получает заказ и приводит его к словарю.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: Данные заказа.

        Raises:
            NotFoundError: Если заказ не найден.
        """
        order = await self.get(key="id", value=order_id)

        if not order:
            raise NotFoundError("Заказ не найден")

        return order.model_dump() if isinstance(order, BaseSchema) else order

    async def _get_order_files(self, order_data: dict[str, Any]) -> list[str]:
        """
        Возвращает список UUID файлов заказа.

        Args:
            order_data: Данные заказа.

        Returns:
            list[str]: Список UUID файлов.
        """
        return [
            str(file_data["object_uuid"])
            for file_data in order_data.get("files", [])
        ]

    async def add(self, data: dict[str, Any]) -> BaseSchema | None:
        """
        Создаёт новый заказ и публикует событие в Redis.

        Args:
            data: Данные для создания заказа.

        Returns:
            BaseSchema | None: Созданный заказ.
        """
        try:
            order = await super().add(data=data)

            if order:
                await stream_client.publish_to_redis(
                    message=order,
                    stream=settings.redis.get_stream_name("order-pipeline"),
                )

            return order
        except Exception as exc:
            raise ServiceError from exc

    async def create_skb_order(self, order_id: int) -> dict[str, Any]:
        """
        Создаёт запрос в СКБ-Техно по существующему заказу.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: Данные заказа и ответ от СКБ-Техно.
        """
        try:
            order_data = await self._get_order_data(order_id=order_id)

            if not order_data["is_active"]:
                raise ValueError("Заказ не активен")

            data = {
                "Id": str(order_data["object_uuid"]),
                "OrderId": str(order_data["object_uuid"]),
                "Number": order_data["pledge_cadastral_number"],
                "Priority": settings.skb_api.default_priority,
                "RequestType": order_data["order_kind"]["skb_uuid"],
            }

            result: dict[str, Any] = await self.request_service.add_request(
                data=data
            )

            if result["status_code"] == status.HTTP_200_OK:
                await self.repo.update(
                    key="id",
                    value=order_data["id"],
                    data={
                        "is_send_request_to_skb": True,
                        "response_data": result.get("data"),
                    },
                    load_into_memory=False,
                )

            return {"instance": order_data, "response": result}
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def async_create_skb_order(self, order_id: int) -> dict[str, Any]:
        """
        Публикует заказ в очередь на асинхронную отправку в СКБ-Техно.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: Данные заказа.
        """
        try:
            order_data = await self._get_order_data(order_id=order_id)

            if not order_data["is_active"]:
                raise ValueError("Заказ не активен")

            await stream_client.publish_to_redis(
                message=order_data,
                stream=settings.redis.get_stream_name("order-send"),
            )

            return order_data
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_result(
        self,
        order_id: int,
        response_type: ResponseTypeChoices,
    ) -> Any:
        """
        Получает результат заказа из СКБ-Техно в указанном формате.

        Args:
            order_id: Идентификатор заказа.
            response_type: Формат ответа - JSON или PDF.

        Returns:
            Any: Словарь с результатом обработки.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            result = await self.request_service.get_response_by_order(
                order_uuid=order_data["object_uuid"],
                response_type_str=response_type.value,
            )

            content: dict[str, Any] = {"instance": order_data}

            if isinstance(result, bytes):
                await self.s3_service.upload_file(
                    key=str(order_data["object_uuid"]),
                    original_filename=f"{order_data['object_uuid']}.pdf",
                    content=result,
                )

                file_instance = await self.file_repo.add(
                    data={"object_uuid": order_data["object_uuid"]}
                )

                await self.file_repo.add_link(
                    data={
                        "order_id": order_data["id"],
                        "file_id": file_instance.id,
                    }
                )

                content["response"] = {
                    "content_type": "application/pdf",
                    "stored": True,
                }
                return content

            if result.get("content_type") == "application/json":
                data = result["data"]

                await self.repo.update(
                    key="id",
                    value=order_data["id"],
                    data={
                        "errors": data.get("Message"),
                        "response_data": data.get("Data"),
                    },
                    load_into_memory=False,
                )

                content["response"] = result
                return content

            content["response"] = None
            return content
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_and_json_from_skb(
        self,
        order_id: int,
    ) -> dict[str, Any] | None:
        """
        Получает JSON-результат и, если он готов, PDF-файл заказа из СКБ-Техно.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any] | None: JSON-ответ с информацией по заказу.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            if not order_data["is_active"]:
                return {"hasError": True, "message": "Inactive order"}

            json_result = await self.get_order_result(
                order_id=order_id,
                response_type=ResponseTypeChoices.json,
            )

            has_pdf_result = await utilities.safe_get(
                json_result,
                "response.data.Result",
                False,
            )

            if has_pdf_result:
                await self.get_order_result(
                    order_id=order_id,
                    response_type=ResponseTypeChoices.pdf,
                )

            update_data: dict[str, Any] = {
                "response_data": json_result.get("response", {}).get(
                    "data", {}
                )
            }

            message = await utilities.safe_get(
                json_result,
                "response.data.Message",
                "Не готов",
            )

            if not message:
                update_data["is_active"] = False

            await self.repo.update(
                key="id",
                value=order_id,
                data=update_data,
                load_into_memory=False,
            )

            return json_result
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_from_storage(self, order_id: int) -> Any:
        """
        Получает файл заказа из S3.

        Если файлов несколько, возвращает zip-архив.
        Если файл один, возвращает его напрямую.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            Any: Файл, zip-архив или None.
        """
        try:
            order_data = await self._get_order_data(order_id=order_id)
            files = await self._get_order_files(order_data=order_data)

            if not files:
                return None

            if len(files) > 1:
                return await self.s3_service.create_zip_archive(files)

            return await self.s3_service.download_file(files[0])
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_from_storage_base64(
        self,
        order_id: int,
    ) -> dict[str, list[dict[str, str]]]:
        """
        Получает файлы заказа из S3 в формате Base64.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, list[dict[str, str]]]: Файлы в формате Base64.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            files = [
                {
                    "file": await self.s3_service.get_file_base64(
                        key=str(file_data["object_uuid"])
                    )
                }
                for file_data in order_data.get("files", [])
            ]

            return {"files": files}
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_from_storage_link(
        self,
        order_id: int,
    ) -> dict[str, list[dict[str, str]]]:
        """
        Получает ссылки на скачивание файлов заказа из S3.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, list[dict[str, str]]]: Ссылки на файлы.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            links = [
                {
                    "file": await self.s3_service.generate_download_url(
                        key=str(file_data["object_uuid"])
                    )
                }
                for file_data in order_data.get("files", [])
            ]

            return {"links": links}
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_link_and_json_result_for_request(
        self,
        order_id: int,
    ) -> dict[str, Any]:
        """
        Возвращает JSON-результат заказа и ссылки на файлы.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: JSON-результат, ошибки и ссылки на файлы.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            response: dict[str, Any] = {
                "data": order_data.get("response_data"),
                "errors": order_data.get("errors"),
            }

            if order_data.get("files"):
                files_links = await self.get_order_file_from_storage_link(
                    order_id=order_id
                )
                response["file_links"] = files_links.get("links", [])

            return response
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def get_order_file_base64_and_json_result_for_request(
        self,
        order_id: int,
    ) -> dict[str, Any]:
        """
        Возвращает JSON-результат заказа и файлы в формате Base64.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: JSON-результат, ошибки и файлы в Base64.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            response: dict[str, Any] = {
                "data": order_data.get("response_data"),
                "errors": order_data.get("errors"),
            }

            if order_data.get("files"):
                files_base64 = await self.get_order_file_from_storage_base64(
                    order_id=order_id
                )
                response["files"] = files_base64.get("files", [])

            return response
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def async_get_order_file_and_json_from_skb(
        self,
        order_id: int,
    ) -> dict[str, Any]:
        """
        Публикует задачу на асинхронное получение результата заказа.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any]: Данные заказа.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_data = await self._get_order_data(order_id=order_id)

            await stream_client.publish_to_redis(
                message=order_data,
                stream=settings.redis.get_stream_name("order-get-result"),
            )

            return order_data
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc

    async def send_order_data(self, order_id: int) -> dict[str, Any] | None:
        """
        Отправляет данные заказа во внешнюю очередь.

        Args:
            order_id: Идентификатор заказа.

        Returns:
            dict[str, Any] | None: Подготовленные данные заказа.
        """
        try:
            await response_cache.invalidate_pattern(
                pattern=self.__class__.__name__
            )

            order_payload = (
                await self.get_order_file_base64_and_json_result_for_request(
                    order_id=order_id
                )
            )

            result: dict[str, Any] = {
                "response": order_payload.get("data", {}),
                "errors": order_payload.get("errors", {}),
                "files": order_payload.get("files", []),
            }

            await stream_client.publish_to_rabbit(
                message=result,
                queue=settings.queue.get_queue_name("order-send"),
            )

            await self.repo.update(
                key="id",
                value=order_id,
                data={
                    "is_send_to_gd": True,
                    "is_active": False,
                },
                load_into_memory=False,
            )

            return order_payload
        except NotFoundError:
            raise
        except Exception as exc:
            raise ServiceError from exc


def get_order_service() -> OrderService:
    """
    Возвращает экземпляр сервиса для работы с заказами.

    Returns:
        OrderService: Экземпляр сервиса заказов.
    """
    return OrderService(
        repo=get_order_repo(),
        schema_out=OrderSchemaOut,
        schema_in=OrderSchemaIn,
        version_schema=OrderVersionSchemaOut,
        request_service=get_skb_service(),
        file_repo=get_file_repo(),
        s3_service=get_s3_service_dependency(),
    )
