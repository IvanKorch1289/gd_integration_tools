from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.utils.logging_service import app_logger


__all__ = ("lifespan",)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Управляет жизненным циклом приложения FastAPI.
    """
    from app.infra.application.setup_infra import ending, starting
    from app.services.infra_services.register_actions import (
        register_action_handlers,
    )

    app_logger.info("Запуск приложения...")
    startup_completed = False

    try:
        await starting()
        register_action_handlers()

        startup_completed = True
        app.state.infrastructure_ready = True
        app.state.action_handlers_ready = True

        app_logger.info("Приложение успешно запущено")
        yield

    except Exception as exc:
        if not startup_completed:
            app_logger.critical(
                "Критическая ошибка при запуске приложения: %s",
                str(exc),
                exc_info=True,
            )
            raise RuntimeError(
                "Остановка приложения из-за ошибки инициализации"
            ) from exc

        app_logger.critical(
            "Критическая ошибка во время работы приложения: %s",
            str(exc),
            exc_info=True,
        )
        raise

    finally:
        app_logger.info("Завершение работы приложения...")
        app.state.infrastructure_ready = False
        app.state.action_handlers_ready = False

        try:
            await ending()
        except Exception as shutdown_exc:
            app_logger.error(
                "Ошибка при завершении работы приложения: %s",
                str(shutdown_exc),
                exc_info=True,
            )

        app_logger.info("Приложение остановлено")
