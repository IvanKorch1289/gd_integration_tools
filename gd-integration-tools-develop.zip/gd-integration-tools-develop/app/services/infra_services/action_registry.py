from typing import Any, Awaitable, Callable

import inspect
from dataclasses import dataclass
from pydantic import BaseModel

from app.api.dsl.invocation import InvocationSpec
from app.schemas.invocation import ActionCommandSchema, InvocationOptionsSchema
from app.services.infra_services.action_bus import get_action_bus_service
from app.utils.enums.invocation import InvokeMode
from app.utils.errors import NotFoundError, ServiceError


__all__ = (
    "ActionHandlerSpec",
    "ActionHandlerRegistry",
    "action_handler_registry",
)


ServiceFactory = Callable[[], Any]
PayloadMapper = Callable[[dict[str, Any]], dict[str, Any]]
ResponseHandler = Callable[[Any], Any | Awaitable[Any]]


@dataclass(slots=True)
class ActionHandlerSpec:
    """
    DSL-описание обработчика action-команды.
    """

    action: str
    service_getter: ServiceFactory
    service_method: str
    payload_model: type[BaseModel] | None = None
    payload_mapper: PayloadMapper | None = None
    response_handler: ResponseHandler | None = None
    allow_reinvoke: bool = False
    invocation: InvocationSpec | None = None


class ActionHandlerRegistry:
    """
    Реестр обработчиков action-команд.
    """

    def __init__(self) -> None:
        self._handlers: dict[str, ActionHandlerSpec] = {}

    def register(
        self,
        action: str | ActionHandlerSpec,
        *,
        service_getter: ServiceFactory | None = None,
        service_method: str | None = None,
        payload_model: type[BaseModel] | None = None,
        payload_mapper: PayloadMapper | None = None,
        response_handler: ResponseHandler | None = None,
        allow_reinvoke: bool = False,
        invocation: InvocationSpec | None = None,
    ) -> None:
        if isinstance(action, ActionHandlerSpec):
            spec = action
        else:
            if service_getter is None or service_method is None:
                raise ValueError(
                    "service_getter and service_method are required."
                )

            spec = ActionHandlerSpec(
                action=action,
                service_getter=service_getter,
                service_method=service_method,
                payload_model=payload_model,
                payload_mapper=payload_mapper,
                response_handler=response_handler,
                allow_reinvoke=allow_reinvoke,
                invocation=invocation,
            )

        if spec.action in self._handlers:
            raise ValueError(f"Handler already registered: {spec.action}")

        self._handlers[spec.action] = spec

    def register_many(self, specs: list[ActionHandlerSpec]) -> None:
        for spec in specs:
            self.register(spec)

    async def dispatch(self, command: ActionCommandSchema) -> Any:
        spec = self._handlers.get(command.action)
        if spec is None:
            raise NotFoundError(f"Action handler not found: {command.action}")

        service = spec.service_getter()
        service_method = getattr(service, spec.service_method)

        payload = dict(command.payload)
        invoke = self._extract_invoke(spec=spec, payload=payload)

        if spec.payload_model is not None:
            payload = spec.payload_model.model_validate(payload).model_dump(
                exclude_none=True
            )

        if spec.payload_mapper is not None:
            payload = spec.payload_mapper(payload)

        async def direct_call() -> Any:
            call_kwargs = dict(payload)

            if (
                spec.invocation is not None
                and spec.invocation.include_invocation_in_service_call
                and invoke is not None
            ):
                call_kwargs[spec.invocation.invocation_argument_name] = invoke

            result = service_method(**call_kwargs)
            if inspect.isawaitable(result):
                result = await result
            return result

        if self._should_reinvoke(spec=spec, invoke=invoke):
            result = await get_action_bus_service().invoke_from_command(
                command=command,
                invoke=invoke,  # type: ignore[arg-type]
                publish_spec=spec.invocation.event,  # type: ignore[union-attr]
                direct_call=direct_call,
                source_kwargs=payload,
            )
        else:
            try:
                result = await direct_call()
            except Exception as exc:
                raise ServiceError from exc

        if spec.response_handler is not None:
            handled = spec.response_handler(result)
            if inspect.isawaitable(handled):
                return await handled
            return handled

        return result

    @staticmethod
    def _extract_invoke(
        *,
        spec: ActionHandlerSpec,
        payload: dict[str, Any],
    ) -> InvocationOptionsSchema | None:
        raw_invoke = payload.pop("invoke", None)
        if raw_invoke is None:
            return None

        model = (
            spec.invocation.model
            if spec.invocation is not None
            else InvocationOptionsSchema
        )
        return model.model_validate(raw_invoke)

    @staticmethod
    def _should_reinvoke(
        *,
        spec: ActionHandlerSpec,
        invoke: InvocationOptionsSchema | None,
    ) -> bool:
        if not spec.allow_reinvoke:
            return False

        if spec.invocation is None or spec.invocation.event is None:
            return False

        if invoke is None:
            return False

        is_scheduled = (
            invoke.delay_seconds is not None or invoke.cron is not None
        )

        return invoke.mode == InvokeMode.event or is_scheduled


action_handler_registry = ActionHandlerRegistry()
