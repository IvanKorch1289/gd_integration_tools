from fastapi import APIRouter, Depends, Response

from app.api.dependencies.auth import require_api_key
from app.api.dsl.actions import ActionRouterBuilder, ActionSpec
from app.schemas.route_schemas.skb import (
    APISKBOrderSchemaIn,
    SKBObjectsByAddressQuerySchema,
    SKBOrdersListQuerySchema,
    SKBResultQuerySchema,
)
from app.services.route_services.skb import get_skb_service
from app.utils.enums.skb import ResponseTypeChoices


__all__ = ("router",)


router = APIRouter()


def build_skb_result_response(
    result: object, action_kwargs: dict[str, object]
):
    """
    Формирует HTTP-ответ для результата запроса из СКБ-Техно.

    Логика:
    - если клиент запросил PDF, сервис возвращает бинарное содержимое файла,
      и transport-слой упаковывает его в Response;
    - если клиент запросил JSON, результат возвращается как есть.

    Args:
        result: Результат работы service method.
        action_kwargs: Подготовленные аргументы, переданные в service method.

    Returns:
        Response | object: HTTP Response для PDF или JSON-совместимый объект.
    """
    response_type = action_kwargs.get("response_type_str")

    if response_type == ResponseTypeChoices.pdf.value:
        return Response(
            content=result,
            media_type="application/pdf",
            headers={"Content-Disposition": "attachment; filename=result.pdf"},
        )

    return result


ActionRouterBuilder(router).add_actions(
    [
        ActionSpec(
            name="get_skb_kinds",
            method="GET",
            path="/get-kinds",
            summary="Получить справочник видов из СКБ Техно",
            description="Возвращает справочник видов запросов из СКБ-Техно.",
            service_getter=get_skb_service,
            service_method="get_request_kinds",
            dependencies=[Depends(require_api_key)],
        ),
        ActionSpec(
            name="create_skb_request",
            method="POST",
            path="/create-request",
            summary="Создать запрос на получение данных по залогу в СКБ Техно",
            description=(
                "Создаёт запрос на получение данных по залогу в СКБ-Техно."
            ),
            service_getter=get_skb_service,
            service_method="add_request",
            body_model=APISKBOrderSchemaIn,
            body_argument_name="data",
            dependencies=[Depends(require_api_key)],
        ),
        ActionSpec(
            name="get_skb_result",
            method="GET",
            path="/get-result",
            summary="Получить результат по залогу в СКБ Техно",
            description=(
                "Возвращает результат запроса в формате JSON или PDF."
            ),
            service_getter=get_skb_service,
            service_method="get_response_by_order",
            query_model=SKBResultQuerySchema,
            argument_aliases={"response_type": "response_type_str"},
            response_handler=build_skb_result_response,
            dependencies=[Depends(require_api_key)],
            responses={
                200: {
                    "content": {
                        "application/json": {},
                        "application/pdf": {},
                        "application/octet-stream": {},
                    },
                    "description": (
                        "Возвращает результат в формате JSON или PDF."
                    ),
                }
            },
        ),
        ActionSpec(
            name="get_skb_orders_list",
            method="GET",
            path="/get-orders-list",
            summary=(
                "Получить список заказов документов по залогу в СКБ Техно"
            ),
            description="Возвращает список созданных заказов.",
            service_getter=get_skb_service,
            service_method="get_orders_list",
            query_model=SKBOrdersListQuerySchema,
            dependencies=[Depends(require_api_key)],
        ),
        ActionSpec(
            name="get_objects_by_address",
            method="POST",
            path="/get-objects-by-address",
            summary=(
                "Проверка-поиск объектов недвижимости по адресу "
                "(ФИАС/КЛАДР)."
            ),
            description=(
                "Выполняет поиск объектов недвижимости по адресу "
                "через API СКБ-Техно."
            ),
            service_getter=get_skb_service,
            service_method="get_objects_by_address",
            query_model=SKBObjectsByAddressQuerySchema,
            dependencies=[Depends(require_api_key)],
        ),
    ]
)
