from app.config.settings.app import get_app_settings
from app.infra.application.app_factory import create_app


settings = get_app_settings()
app = create_app()


def run() -> None:
    import uvicorn

    uvicorn_kwargs = {
        "app": "main:app",
        "host": settings.host,
        "port": settings.port,
        "log_level": "debug" if settings.debug_mode else "info",
        "use_colors": settings.environment != "production",
        "limit_concurrency": 1000,
        "timeout_keep_alive": 30,
    }

    if settings.environment in {"development", "testing"}:
        uvicorn_kwargs["reload"] = settings.debug_mode
    else:
        uvicorn_kwargs["workers"] = 1

    uvicorn.run(**uvicorn_kwargs)


if __name__ == "__main__":
    run()
