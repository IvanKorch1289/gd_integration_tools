--
-- PostgreSQL database dump
--

\restrict 5BhOJ9cnAes3ksjg2dUaawDt4psMYVk5qDMGMQ5Q32hBjCEukTxMx9qebJHpkJo

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

-- Started on 2026-09-29 12:00:02 MSK

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 16393)
-- Name: drill_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drill_events (
    id integer NOT NULL,
    kind text
);


--
-- TOC entry 216 (class 1259 OID 16392)
-- Name: drill_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drill_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3461 (class 0 OID 0)
-- Dependencies: 216
-- Name: drill_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drill_events_id_seq OWNED BY public.drill_events.id;


--
-- TOC entry 215 (class 1259 OID 16385)
-- Name: drill_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drill_items (
    id integer NOT NULL,
    payload text
);


--
-- TOC entry 3305 (class 2604 OID 16396)
-- Name: drill_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drill_events ALTER COLUMN id SET DEFAULT nextval('public.drill_events_id_seq'::regclass);


--
-- TOC entry 3455 (class 0 OID 16393)
-- Dependencies: 217
-- Data for Name: drill_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drill_events (id, kind) FROM stdin;
1	created
2	updated
\.


--
-- TOC entry 3453 (class 0 OID 16385)
-- Dependencies: 215
-- Data for Name: drill_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drill_items (id, payload) FROM stdin;
1	alpha
2	beta
3	gamma
4	payload_4
5	payload_5
6	payload_6
7	payload_7
8	payload_8
9	payload_9
10	payload_10
11	payload_11
12	payload_12
13	payload_13
14	payload_14
15	payload_15
16	payload_16
17	payload_17
18	payload_18
19	payload_19
20	payload_20
21	payload_21
22	payload_22
23	payload_23
24	payload_24
25	payload_25
26	payload_26
27	payload_27
28	payload_28
29	payload_29
30	payload_30
31	payload_31
32	payload_32
33	payload_33
34	payload_34
35	payload_35
36	payload_36
37	payload_37
38	payload_38
39	payload_39
40	payload_40
41	payload_41
42	payload_42
43	payload_43
44	payload_44
45	payload_45
46	payload_46
47	payload_47
48	payload_48
49	payload_49
50	payload_50
\.


--
-- TOC entry 3462 (class 0 OID 0)
-- Dependencies: 216
-- Name: drill_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drill_events_id_seq', 2, true);


--
-- TOC entry 3309 (class 2606 OID 16400)
-- Name: drill_events drill_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drill_events
    ADD CONSTRAINT drill_events_pkey PRIMARY KEY (id);


--
-- TOC entry 3307 (class 2606 OID 16391)
-- Name: drill_items drill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drill_items
    ADD CONSTRAINT drill_items_pkey PRIMARY KEY (id);


-- Completed on 2026-09-29 12:00:02 MSK

--
-- PostgreSQL database dump complete
--

\unrestrict 5BhOJ9cnAes3ksjg2dUaawDt4psMYVk5qDMGMQ5Q32hBjCEukTxMx9qebJHpkJo

