# DSL tools

Короткая инструкция по новому DSL-слою.

## Что появилось

### 1. Action DSL
Файл: `app/api/dsl/actions.py`

Есть 2 основные спецификации:

- `ActionSpec` — для action/manual endpoints.
- `CrudSpec` — для генерации CRUD-роутов без CBV.

### 2. Resource generator
Файл: `tools/generate_resource.py`

Генерирует заготовки:

- `app/api/v1/endpoints/<resource>.py`
- `app/services/route_services/<resource>.py`
- `app/repositories/<resource>.py`
- `app/schemas/route_schemas/<resource>.py`
- `app/models/<resource>.py`

## Примеры

### CRUD-ресурс через DSL

```python
from fastapi import APIRouter, Depends

from app.api.dependencies.auth import require_api_key
from app.api.dsl.actions import ActionRouterBuilder, CrudSpec
from app.schemas.route_schemas.users import UserSchemaIn, UserSchemaOut, UserVersionSchemaOut
from app.services.route_services.users import get_user_service
from app.utils.decorators.limiting import route_limiting

router = APIRouter()
builder = ActionRouterBuilder(router)

builder.add_crud_resource(
    CrudSpec(
        name="users",
        service_getter=get_user_service,
        schema_in=UserSchemaIn,
        schema_out=UserSchemaOut,
        version_schema=UserVersionSchemaOut,
        dependencies=[Depends(require_api_key)],
        decorators=[route_limiting],
        tags=("Users",),
    )
)
```

### Action endpoint через DSL

```python
builder.add_action(
    ActionSpec(
        name="send_user_notification",
        method="POST",
        path="/send-notification/",
        summary="Отправить уведомление",
        service_getter=get_user_service,
        service_method="send_notification",
        body_model=NotificationSchemaIn,
        body_argument_name="body",
        dependencies=[Depends(require_api_key)],
        decorators=[route_limiting],
        tags=("Users",),
    )
)
```

## Генерация заготовки

```bash
python tools/generate_resource.py users
```

С перезаписью:

```bash
python tools/generate_resource.py users --force
```

## План миграции CBV

1. Создать DSL-версию endpoint-файла.
2. Заменить `create_router_class(...)` на `CrudSpec(...)`.
3. Оставить custom endpoints как `ActionSpec(...)`.
4. Проверить Swagger/OpenAPI.
5. После перевода всех модулей удалить `app/api/routers_factory.py`.

## Что не удалять

Не удалять runtime-слой:

- `action_bus.py`
- `invocation.py`
- `stream.py`
- `caching.py`

Это базовые инфраструктурные компоненты DSL.
